﻿#include <iostream>
using namespace std;

int main()
{
    setlocale(LC_ALL, "RU");
    char symbol;
    cout << "Чтобы выйти из программы - нажмите 0." << endl;
    do {
        cout << "Введите символ: ";
        cin >> symbol;
        if (int(symbol == 48)) {
            break;
        }
        else if (int(symbol >= 65 && symbol <= 90)
            || int(symbol >= 97 && symbol <= 122)
            || int(symbol >= -128 && symbol <= -17)) {
            cout << "Введена буква." << endl;
        }
        else if (int(symbol >= 48 && symbol <= 57)) {
            cout << "Введена цифра." << endl;
        }
        else if (int(symbol >= 32 && symbol <= 47 || symbol >= 58 && symbol <= 64
            || symbol >= 91 && symbol <= 96 || symbol >= 123 && symbol <= 127)) {
            cout << "Введен знак пунктуации." << endl;
        }
        else {
            cout << "Введен неизвестный программе символ!" << endl;

        }
        cout << int(symbol) << endl;
    } while (true);

    return 0;
}
