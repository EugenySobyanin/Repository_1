﻿#include <iostream>
#include <time.h>


int main()
{
    using namespace std;
    setlocale(LC_ALL, "RU");
    srand(time(0));
    const int len = 10;
    int numbers[len]{}, nums_1[len / 2]{}, nums_2[len / 2]{};

    for (int i = 0; i < len; i++)
    {
        numbers[i] = rand() % 20;
        cout << numbers[i] << " ";
    }
    cout << endl;

    for (int i = 0; i < len / 2; i++)
    {
        nums_1[i] = numbers[i * 2];
        cout << nums_1[i] << " ";

    }
    cout << endl;

    for (int i = 0; i < len / 2; i++)
    {
        nums_2[i] = numbers[i * 2 + 1];
        cout << nums_2[i] << " ";

    }
    cout << endl;

    return 0;
}

