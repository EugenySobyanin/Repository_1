﻿#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    setlocale(LC_ALL, "RU");
    long long num;
    cout << "Введите целое число: ";
    cin >> num;
    int i = 0, result = 0;
    while (num > 0) {
        int a = num % 10;
        num /= 10;
        if (a != 3 && a != 6) {
            if (i == 0) {
                result += a;
                i++;

            }
            else {
                result += a * (pow(10, i));
                i++;
            }

        }
    }
    cout << "Результат = " << result << endl;
}

