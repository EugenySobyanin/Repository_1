<?php
require_once __DIR__ . '/User.php';
require_once __DIR__ . '/db.php';
session_start();

if (isset($_SESSION['user'])) {
    // Показываем данные из сессии
    echo $_SESSION['user']->show();
    
    // Дополнительно можно получить свежие данные из БД
    try {
        $stmt = $connection->prepare("SELECT * FROM Users WHERE id = ?");
        $stmt->execute([$_SESSION['user']->id]);
        $userData = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo "<div><h3>Данные из базы:</h3><pre>".print_r($userData, true)."</pre></div>";
    } catch(Exception $e) {
        echo "<div class='error'>Ошибка получения данных: ".$e->getMessage()."</div>";
    }
} 
else {
    echo '<p>Пользователь не зарегистрирован. <a href="registration.php">Зарегистрироваться</a></p>';
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>

</body>
</html>