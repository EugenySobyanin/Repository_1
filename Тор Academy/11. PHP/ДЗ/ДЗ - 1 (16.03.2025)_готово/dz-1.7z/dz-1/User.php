<?php
class User {
    public $id;
    public $name;
    public $email;
    public $password;

    public function __construct($name, $email, $password, $id = null) {
        $this->name = $name;
        $this->email = $email;
        $this->password = password_hash($password, PASSWORD_DEFAULT);
        $this->id = $id;
    }

    public function show() {
        return "<div>
            <h2>Информация о пользователе</h2>
            <p><strong>ID:</strong> {$this->id}</p>
            <p><strong>Имя:</strong> {$this->name}</p>
            <p><strong>Email:</strong> {$this->email}</p>
        </div>";
    }

    /*Метод для сохранения в БД. */
    public function toDb($connection) {
    try {
        $stmt = $connection->prepare("INSERT INTO Users (name, email, password) VALUES (:name, :email, :password)");
        
        // Для PDO используем bindValue() или передаем массив в execute()
        $stmt->bindValue(':name', $this->name, PDO::PARAM_STR);
        $stmt->bindValue(':email', $this->email, PDO::PARAM_STR);
        $stmt->bindValue(':password', $this->password, PDO::PARAM_STR);
        
        if ($stmt->execute()) {
            $this->id = $connection->lastInsertId();
            return true;
        }
    } catch(PDOException $e) {
        throw new Exception("Ошибка при сохранении пользователя: " . $e->getMessage());
    }
    return false;
}
}
?>