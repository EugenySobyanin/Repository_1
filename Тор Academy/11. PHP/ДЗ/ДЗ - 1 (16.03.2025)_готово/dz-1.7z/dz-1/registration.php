<?php
require_once __DIR__ . '/User.php';
require_once __DIR__ . '/db.php';
session_start();


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Получаем данные из формы
        $name = $_POST['name'] ?? '';
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';

        // Создаем объект пользователя
        $user = new User($name, $email, $password);

        // Cохраняем в базу данных и в сессию
        if ($user->toDb($connection)) {
            $_SESSION['user'] = $user;
            // Перенаправляем на главную страницу
            header('Location: index.php');
        }
    } catch(Exception $e) {
        $error = $e->getMessage();
    }   
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Регистрация</title>
  <link rel="stylesheet" href="css/styles.css">
  <link rel="stylesheet" href="css/reg_form.css">
</head>
<body>
  <div class="main-div">

    <?php if (!empty($error)): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
  
    <div class="main-form-div">
    <h2 class="title">Форма регистрации</h2>
    <form method="POST" action="registration.php">
        <div class="form-input-div">
            <input type="text" name="name" placeholder="Username" required>
        </div>
        <div class="form-input-div">
            <input type="email" name="email" placeholder="Email" required>
        </div>
        <div class="form-input-div">
            <input type="password" name="password" placeholder="Password" required>
        </div>
        <div class="form-input-div">
            <input type="password" name="password" placeholder="Confirm password" required>
        </div>
        <button type="submit">Зарегистрироваться</button>
    </form>
  </div>
  </div>
  
</body>
</html>