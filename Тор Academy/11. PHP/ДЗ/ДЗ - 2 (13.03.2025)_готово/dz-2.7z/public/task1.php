<?php
// Инициализация переменных
$red = $green = $blue = '';
$colorStyle = '';

// Обработка формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $red = isset($_POST["red"]) ? (int)$_POST["red"] : 0;
    $green = isset($_POST["green"]) ? (int)$_POST["green"] : 0;
    $blue = isset($_POST["blue"]) ? (int)$_POST["blue"] : 0;
    
    // Ограничиваем значения от 0 до 255
    $red = max(0, min(255, $red));
    $green = max(0, min(255, $green));
    $blue = max(0, min(255, $blue));
    
    // Формируем строку стиля
    $colorStyle = "background-color: rgb($red, $green, $blue);";
}

$html = <<<HTML
<div class="main-div">
  <form method="POST">
    <h3>ГЕНЕРАТОР ЦВЕТА RGB</h3>
    <div class="input-div">
      <input type="text" name="red" placeholder="RED (0-255)" value="$red" min="0" max="255">
    </div>
    <div class="input-div">
      <input type="text" name="green" placeholder="Green (0-255)" value="$green" min="0" max="255">
    </div>
    <div class="input-div">
      <input type="text" name="blue" placeholder="Blue (0-255)" value="$blue" min="0" max="255">
    </div>
    <div>
      <button type="submit">Accept</button>
    </div>
  </form>
  <div class="result-div" style="$colorStyle">
  </div>
</div>
HTML;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Задание 1</title>
    <link rel="stylesheet" href="css/styles_task1.css">
</head>
<body>
  <?php
    echo $html;
  ?>    
</body>
</html>