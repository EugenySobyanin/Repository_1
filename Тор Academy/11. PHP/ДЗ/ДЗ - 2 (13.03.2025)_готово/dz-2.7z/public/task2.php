<?php

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    displayCalendar($_POST['month']);
}

/**
 * Функция для отображения календаря на указанный месяц
 * @param int $month Номер месяца (1-12)
 */
function displayCalendar($month = '') {
    // ========== ВАЛИДАЦИЯ ВХОДНЫХ ДАННЫХ ==========
    if ($month === null || $month == '') {
        echo "<p class='error'>Введите значение месяца.</p>";
        return;
    }
    if ($month < 1 || $month > 12) {
        echo "<p class='error'>Некорректный номер месяца. Введите значение от 1 до 12.</p>";
        return;
    }

    // ========== ПОДГОТОВКА ДАННЫХ ==========
    $year = date('Y'); // Получаем текущий год
    // Создаем timestamp для первого дня месяца
    $firstDay = mktime(0, 0, 0, $month, 1, $year);
    // Количество дней в месяце (функция date('t') возвращает число дней)
    $daysInMonth = date('t', $firstDay);
    // День недели для первого дня месяца (0-воскресенье, 1-понедельник...6-суббота)
    $firstDayOfWeek = date('w', $firstDay);
    // Преобразуем воскресенье (0) в 7 для удобства расчетов
    $firstDayOfWeek = $firstDayOfWeek == 0 ? 7 : $firstDayOfWeek;
    
    // Массив с названиями месяцев на русском
    $monthNames = [
        1 => 'Январь', 2 => 'Февраль', 3 => 'Март', 4 => 'Апрель',
        5 => 'Май', 6 => 'Июнь', 7 => 'Июль', 8 => 'Август',
        9 => 'Сентябрь', 10 => 'Октябрь', 11 => 'Ноябрь', 12 => 'Декабрь'
    ];
    
    // ========== ВЫВОД КАЛЕНДАРЯ ==========
    // Главный div для всего календаря
    echo "<div class='calendar-div form-div'>";

    // Заголовок с названием месяца и года
    echo "<div class='month-title'>{$monthNames[$month]} $year</div>";
    
    // Начало таблицы
    echo "<table class='calendar'>";
    
    // Заголовок таблицы с днями недели
    echo "<tr>
            <th>Пн</th>
            <th>Вт</th>
            <th>Ср</th>
            <th>Чт</th>
            <th>Пт</th>
            <th class='weekend'>Сб</th>
            <th class='weekend'>Вс</th>
          </tr>";
    
    // Текущий день месяца (начинаем с 1)
    $currentDay = 1;
    // Получаем текущий день и месяц для выделения
    $today = date('j');
    $currentMonth = date('n');
    
    // ========== ГЕНЕРАЦИЯ СТРОК КАЛЕНДАРЯ ==========
    // Максимум 6 строк (недель) в календаре
    for ($week = 0; $week < 6; $week++) {
        // Прерываем цикл если прошли все дни месяца
        if ($currentDay > $daysInMonth) break;
        
        echo "<tr>"; // Начало строки
        
        // Проходим по 7 дням недели
        for ($dayOfWeek = 1; $dayOfWeek <= 7; $dayOfWeek++) {
            // Если это первая неделя и день недели меньше первого дня месяца
            // ИЛИ если прошли все дни месяца - выводим пустую ячейку
            if (($week == 0 && $dayOfWeek < $firstDayOfWeek) || $currentDay > $daysInMonth) {
                echo "<td></td>";
            } else {
                // Проверяем является ли день выходным (суббота или воскресенье)
                $isWeekend = ($dayOfWeek >= 6);
                // Проверяем является ли день текущим днем в текущем месяце
                $isToday = ($currentDay == $today && $month == $currentMonth);
                
                // Формируем классы для ячейки
                $class = $isWeekend ? 'weekend' : '';
                $class .= $isToday ? ' today' : '';
                
                // Выводим ячейку с числом
                echo "<td class='$class'>$currentDay</td>";
                $currentDay++; // Переходим к следующему дню
            }
        }
        
        echo "</tr>"; // Конец строки
    }
    
    echo "</table>"; // Конец таблицы

    echo "</div>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Задание 2</title>
    <link rel="stylesheet" href="css/styles_task2.css">
</head>
<body>
  <div class="form-div">
    <h3>КАЛЕНДАРЬ</h3>
    <form method="POST">
      <div class="input-div">
        <input type="text" name="month" placeholder="Введите номер месяца (1-12):" min="1" max="12">
      </div>
      <div>
        <button type="submit">Генерировать календарь</button>
      </div>
    </form>
  </div>
</body>
</html>