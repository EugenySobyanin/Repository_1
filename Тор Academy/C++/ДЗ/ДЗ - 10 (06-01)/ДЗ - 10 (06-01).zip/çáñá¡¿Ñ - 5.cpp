﻿#include <iostream>
using namespace std;

int main()
{
    setlocale(LC_ALL, "RU");
    int k;
    cout << "Введите число: ";
    cin >> k;
    for (int i = 1; i <= 10; i++) {
        cout << k << " * " << i << " = " << i * k << endl;
    }


    return 0;
}


