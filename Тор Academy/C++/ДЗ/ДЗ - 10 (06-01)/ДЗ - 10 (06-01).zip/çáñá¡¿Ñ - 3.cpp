﻿#include <iostream>
#include <cmath>
using namespace std;


int main()
{
    setlocale(LC_ALL, "RU");
    float sum = 0.0;
    for (int i = 1; i <= 1000; i++) {
        sum += i;
        if (i == 1000) {
            sum /= i;
        }
    }
    cout << "Среднее арифметическое: " << sum << endl;
}
