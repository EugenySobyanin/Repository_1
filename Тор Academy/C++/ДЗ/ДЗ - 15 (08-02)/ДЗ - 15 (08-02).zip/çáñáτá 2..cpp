﻿#include <iostream>


int main()
{
	using namespace std;
	setlocale(LC_ALL, "RU");
	srand(time(0));

	const int numbers_len = 100;
	int numbers[numbers_len]{}, left_num, right_num, num, sum = 0;

	cout << "Введите диапазон: ";
	cin >> left_num >> right_num;
	cout << "Введите число для сравнения: ";
	cin >> num;
	int temp;
	if (left_num > right_num) {
		swap(left_num, right_num);
	}

	for (int i = 0; i < numbers_len; i++) {
		numbers[i] = rand() % 100 + 1;
		cout << i << " - " << numbers[i] << endl;
	}
	cout << endl;

	for (int j = left_num; j <= right_num; j++) {
		if (numbers[j] < num) {
			sum += numbers[j];
		}
	}
	cout << "Результат: " << sum << endl;

}