﻿#include <iostream>


int main()
{
	using namespace std;
	setlocale(LC_ALL, "RU");
	srand(time(0));

	const int numbers_len = 10;
	int numbers[numbers_len]{};

	for (int i = 0; i < numbers_len; i++) {
		numbers[i] = rand() % 100 + 1;
		cout << numbers[i] << " ";
	}
	cout << endl;

	int min = numbers[0], max = numbers[0];

	for (int i = 0; i < numbers_len; i++) {
		if (numbers[i] < min) {
			min = numbers[i];
		}
		if (numbers[i] > max) {
			max = numbers[i];
		}
	}
	cout << "Максимальный элемент: " << max << endl
		<< "Минимальный элемент: " << min << endl;

}
