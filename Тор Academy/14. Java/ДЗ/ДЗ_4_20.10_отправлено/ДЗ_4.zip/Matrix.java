import java.util.Random;
import java.util.Scanner;

public class Matrix<T extends Number> {
    private T[][] matrix;
    private int rows;
    private int cols;
    private Random random = new Random();
    private Scanner scanner = new Scanner(System.in);

    // Конструктор
    public Matrix(int rows, int cols) {
        if (rows <= 0 || cols <= 0) {
            throw new IllegalArgumentException("Размеры матрицы должны быть положительными");
        }
        this.rows = rows;
        this.cols = cols;
        // Создаем матрицу типа Object
        this.matrix = (T[][]) new Number[rows][cols];
    }

    // 1. Заполнение матрицы с клавиатуры
    public void fillFromKeyboard() {
        System.out.println("Введите элементы матрицы " + rows + "x" + cols + ":");

        // Определяем тип по первому вводимому элементу
        System.out.print("Введите первый элемент [0][0]: ");
        String firstInput = scanner.next();
        Class<?> type = determineType(firstInput);

        // Заполняем первый элемент
        matrix[0][0] = parseValue(firstInput, type);

        // Заполняем остальные элементы
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (i == 0 && j == 0) continue; // первый уже заполнен

                System.out.printf("Элемент [%d][%d]: ", i, j);
                String input = scanner.next();
                matrix[i][j] = parseValue(input, type);
            }
        }
    }

    // Определение типа по строке
    private Class<?> determineType(String input) {
        try {
            Integer.parseInt(input);
            return Integer.class;
        } catch (NumberFormatException e1) {
            try {
                Double.parseDouble(input);
                return Double.class;
            } catch (NumberFormatException e2) {
                throw new IllegalArgumentException("Поддерживаются только числовые типы");
            }
        }
    }

    // Преобразование строки в значение нужного типа
    @SuppressWarnings("unchecked")
    private T parseValue(String input, Class<?> type) {
        if (type == Integer.class) {
            return (T) Integer.valueOf(Integer.parseInt(input));
        } else if (type == Double.class) {
            return (T) Double.valueOf(Double.parseDouble(input));
        } else {
            throw new IllegalArgumentException("Неподдерживаемый тип");
        }
    }

    // 2. Заполнение случайными значениями
    public void fillRandom(T min, T max) {
        double minVal = min.doubleValue();
        double maxVal = max.doubleValue();

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                double randomValue = minVal + (maxVal - minVal) * random.nextDouble();
                matrix[i][j] = convertToType(randomValue, min.getClass());
            }
        }
    }

    // Преобразование double в нужный тип
    @SuppressWarnings("unchecked")
    private T convertToType(double value, Class<?> type) {
        if (type == Integer.class) {
            return (T) Integer.valueOf((int) Math.round(value));
        } else if (type == Double.class) {
            return (T) Double.valueOf(value);
        } else {
            throw new IllegalArgumentException("Неподдерживаемый тип");
        }
    }

    // 3. Отображение матрицы
    public void display() {
        System.out.println("Матрица " + rows + "x" + cols + ":");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.printf("%8.2f ", matrix[i][j].doubleValue());
            }
            System.out.println();
        }
    }

    // 4. Арифметические операции

    // Сложение
    public Matrix<T> add(Matrix<T> other) {
        checkDimensions(other, "сложения");
        Matrix<T> result = new Matrix<>(rows, cols);

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                double sum = matrix[i][j].doubleValue() + other.matrix[i][j].doubleValue();
                result.matrix[i][j] = convertToType(sum, matrix[i][j].getClass());
            }
        }
        return result;
    }

    // Вычитание
    public Matrix<T> subtract(Matrix<T> other) {
        checkDimensions(other, "вычитания");
        Matrix<T> result = new Matrix<>(rows, cols);

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                double diff = matrix[i][j].doubleValue() - other.matrix[i][j].doubleValue();
                result.matrix[i][j] = convertToType(diff, matrix[i][j].getClass());
            }
        }
        return result;
    }

    // Умножение
    public Matrix<T> multiply(Matrix<T> other) {
        if (this.cols != other.rows) {
            throw new IllegalArgumentException(
                    "Количество столбцов первой матрицы должно равняться количеству строк второй"
            );
        }

        Matrix<T> result = new Matrix<>(this.rows, other.cols);

        for (int i = 0; i < this.rows; i++) {
            for (int j = 0; j < other.cols; j++) {
                double sum = 0.0;
                for (int k = 0; k < this.cols; k++) {
                    sum += this.matrix[i][k].doubleValue() * other.matrix[k][j].doubleValue();
                }
                result.matrix[i][j] = convertToType(sum, this.matrix[0][0].getClass());
            }
        }
        return result;
    }

    // Деление на скаляр
    public Matrix<T> divide(T scalar) {
        if (scalar.doubleValue() == 0) {
            throw new ArithmeticException("Деление на ноль");
        }

        Matrix<T> result = new Matrix<>(rows, cols);

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                double quotient = matrix[i][j].doubleValue() / scalar.doubleValue();
                result.matrix[i][j] = convertToType(quotient, matrix[i][j].getClass());
            }
        }
        return result;
    }

    // 5. Подсчет среднеарифметического значения
    public double calculateAverage() {
        if (rows == 0 || cols == 0) {
            return 0.0;
        }

        double sum = 0.0;
        int count = rows * cols;

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                sum += matrix[i][j].doubleValue();
            }
        }

        return sum / count;
    }

    // Вспомогательные методы
    private void checkDimensions(Matrix<T> other, String operation) {
        if (this.rows != other.rows || this.cols != other.cols) {
            throw new IllegalArgumentException(
                    "Для " + operation + " размеры матриц должны совпадать"
            );
        }
    }

    public int getRows() { return rows; }
    public int getCols() { return cols; }
}