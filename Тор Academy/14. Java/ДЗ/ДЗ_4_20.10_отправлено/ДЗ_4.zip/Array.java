import java.io.Console;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;


public class Array<T extends Comparable<T>> {
    private T[] array;
    private int size;
    private Random random = new Random();
    private Scanner scanner = new Scanner(System.in);

    // Конструкторы

    // Конструктор по умолчанию
    public Array() {
        this(10);
    }

    // Конструктор с начальной вместимостью (capacity)
    public Array(int capacity) {
        if (capacity <= 0) {
            throw new IllegalArgumentException("Вместимость должна быть > 0");
        }
        array = (T[]) new Comparable[capacity];
        this.size = 0;
    }

    // Конструктор с массивом
    public Array(T[] array) {
        if (array == null) {
            throw new IllegalArgumentException("Массив не может быть null");
        }
        this.array = Arrays.copyOf(array, array.length);
        this.size = array.length;
    }

    // 1. Заполнение массива с клавиатуры
    public void fillFromKeyboard() {
        System.out.print("Введите размер массива: ");
        int inputSize = scanner.nextInt();

        // Всегда создаем новый массив, чтобы не оставалось старого хвоста
        array = (T[]) new Comparable[inputSize];
        size = inputSize;

        System.out.println("Введите " + inputSize + " элементов:");

        for (int i = 0; i < inputSize; i++) {
            System.out.print("arr[" + i + "] = ");

            // Реализация для основных типов
            if (array instanceof Integer[]) {
                array[i] = (T) Integer.valueOf(scanner.nextInt());
            } else if (array instanceof Double[]) {
                array[i] = (T) Double.valueOf(scanner.nextDouble());
            } else {
                // Для всего остального читаем строку
                scanner.nextLine();
                String value = scanner.nextLine();
                array[i] = (T) value;
            }
        }
    }

    // 2. Заполнение массива случайными числами
    public void fillRandom(T min, T max) {
        if (!(min instanceof Number) || !(max instanceof Number)) {
            throw new UnsupportedOperationException("Метод доступен только для числовых типов");
        }

        double minVal = ((Number) min).doubleValue();
        double maxVal = ((Number) max).doubleValue();

        for (int i = 0; i < array.length; i++) {
            double randomValue = minVal + (maxVal - minVal) * random.nextDouble();
            if (array instanceof Integer[]) {
                array[i] = (T) Integer.valueOf((int) Math.round(randomValue));
            } else if (array instanceof Double[]) {
                array[i] = (T) Double.valueOf(randomValue);
            } else if (array instanceof Float[]) {
                array[i] = (T) Float.valueOf((float) randomValue);
            }
            size = Math.max(size, i + 1);
        }
    }

    // 3. Отображение массива
    public void printArray() {
        System.out.print("Массив [" + size + "]: ");
        for (int i = 0; i < size; i++) {
            System.out.print(array[i]);
            if (i < size - 1) System.out.print(", ");
        }
        System.out.println();
    }

    // 4. Максимальное значение
    public T max() {
        if (array == null || array.length == 0) {
            throw new IllegalStateException("Массив пуст");
        }

        T max = array[0];
        for (int i = 1; i < array.length; i++) {
            if (array[i].compareTo(max) > 0) {
                max = array[i];
            }
        }
        return max;
    }

    // 5. Минимальное значение
    public T min() {
        if (array == null || array.length == 0) {
            throw new IllegalStateException("Массив пуст");
        }

        T min = array[0];
        for (int i = 1; i < array.length; i++) {
            if (array[i].compareTo(min) < 0) {
                min = array[i];
            }
        }
        return min;

    }

    // 6. Среднеарифметическое (только для числовых типов)
    public double avg() {
        if (size == 0) throw new IllegalStateException("Массив пуст");
        if (!(array[0] instanceof Number)) {
            throw new UnsupportedOperationException("Среднее доступно только для числовых типов");
        }

        double sum = 0.0;
        for (int i = 0; i < size; i++) {
            sum += ((Number) array[i]).doubleValue();
        }
        return sum / size;
    }

    // 7. Сортировка по возрастанию
    public void sortAsc() {
        boolean swapped;
        for (int i = 0; i < array.length; ++i) {
            swapped = false;
            for (int j = 0; j < array.length - 1 - i; ++j) {
                if (array[j].compareTo(array[j+1]) > 0) {
                    T temp = array[j];
                    array[j] = array[j+1];
                    array[j+1] = temp;
                    swapped = true;
                }
            }
            if (!swapped)
                break;
        }
    }

    // 8. Сортировка по убыванию
    public void sortDesc() {
        boolean swapped;
        for (int i = 0; i < array.length - 1; i++) {
            swapped = false;
            for (int j = array.length - 1; j > i; j--) {
                if (array[j].compareTo(array[j-1]) > 0) {
                    T temp = array[j];
                    array[j] = array[j-1];
                    array[j-1] = temp;
                    swapped = true;
                }
            }
            if (!swapped)
                break;
        }
    }

    // 9. Бинарный поиск
    public int binarySerch(T key) {
        this.sortAsc();
        int left = 0;
        int right = size - 1;

        while(left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = key.compareTo(array[mid]);

            if (comparison == 0) {
                return mid; // элемент найден
            } else if (comparison < 0) {
                right = mid - 1; // ищем в левой половине
            } else {
                left = mid + 1; // ищем в правой половине
            }
        }
        return -left - 1;
    }

    // 10. Замена значения
    public boolean replaceValue(T oldValue, T newValue) {
        for (int i = 0; i < size; i++) {
            if (array[i].equals(oldValue)) {
                array[i] = newValue;
                return true;
            }
        }
        return false;
    }

    // 11. Замена по индексу
    public void replaceAtIndex(int index, T value) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Индекс вне диапазона");
        }
        array[index] = value;
    }

    // Вспомогательный метод для увеличения вместимости
    private void ensureCapacity(int minCapacity) {
        if (minCapacity > array.length) {
            int newCapacity = Math.max(array.length * 2, minCapacity);
            array = Arrays.copyOf(array, newCapacity);
        }
    }
}

