package org.example;

import java.time.Year;

public class Book {
    private String title;
    private String authorFullName;
    private Integer releaseYear;
    private String genre;
    private Integer pageCount;

    // Конструктор без параметров
    public Book(){
        title = "Без названию";
        authorFullName = "Неизвестен";
        releaseYear = null;
        genre = null;
        pageCount = null;
    }

    // Конструктор со всеми параметрами
    public Book(String title,
                String authorFullName,
                Integer releaseYear,
                String genre,
                Integer pageCount){
        this.title = title;
        this.authorFullName = authorFullName;
        this.releaseYear = releaseYear;
        this.genre = genre;
        this.pageCount = pageCount;
    }

    // Конструктор с важными параметрами
    public Book(String title, String authorFullName){
        this(title, authorFullName, null, null, null);
    }

    // Геттеры

    public String getTitle() {
        return title;
    }

    public String getAuthorFullName() {
        return authorFullName;
    }

    public Integer getReleaseYear() {
        return releaseYear;
    }

    public String getGenre() {
        return genre;
    }

    public Integer getPageCount() {
        return pageCount;
    }

    // Сеттеры


    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthorFullName(String authorFullName) {
        this.authorFullName = authorFullName;
    }

    public void setReleaseYear(Integer releaseYear) {
        this.releaseYear = releaseYear;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public void setPageCount(Integer pageCount) {
        this.pageCount = pageCount;
    }

    // Метод проверяет новая ли книга (выпущена в текущем году)
    public Boolean isNewBook(){
        if (releaseYear == null) {
            return false;
        }
        return releaseYear == Year.now().getValue();
    }

    // Метода проверяет старая ли книга (> 50 лет)
    public Boolean isOldBook(){
        if (releaseYear == null) {
            return false;
        }
        return Year.now().getValue() - releaseYear > 50;
    }

    // Метод возвращает текущий возраст книги
    public Integer getBookAge(){
        if (releaseYear == null) {
            return null;
        }
        return Year.now().getValue() - releaseYear;
    }

    @Override
    public String toString() {
        return "Книга: '" + title + "'" +
                "\nАвтор: " + authorFullName +
                "\nГод выпуска: " + (releaseYear != null ? releaseYear : "не указан") +
                "\nЖанр: " + genre +
                "\nСтраниц: " + pageCount +
                (releaseYear != null ?
                        "\nВозраст книги: " + getBookAge() + " лет" +
                                "\nНовая книга? " + (isNewBook() ? "Да" : "Нет") +
                                "\nСтарая книга? " + (isOldBook() ? "Да" : "Нет") : "");
    }
}
