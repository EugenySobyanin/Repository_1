package org.example;

public class Car {
    private String title;
    private String producer;
    private Integer releaseYear;
    private Integer engineCapacity;

    // Конструктор без параметров
    public Car(){
        title = "Без названия";
        producer = "Неизвестен";
        releaseYear = 0;
        engineCapacity = 0;
    }
    // Конструктор со всеми параметрами
    public Car(String title, String producer,
               Integer releaseYear, Integer engineCapacity){
        this.title = title;
        this.producer = producer;
        this.releaseYear = releaseYear;
        this.engineCapacity =engineCapacity;
    }
    // Конструктор с важными параметрами
    public Car(String title, String producer){
        this(title, producer, 0, 0);
    }
    // Геттеры

    public String getTitle() {
        return title;
    }

    public String getProducer() {
        return producer;
    }

    public Integer getReleaseYear() {
        return releaseYear;
    }

    public Integer getEngineCapacity() {
        return engineCapacity;
    }

    // Сеттеры

    public void setTitle(String title) {
        this.title = title;
    }

    public void setProducer(String producer) {
        this.producer = producer;
    }

    public void setReleaseYear(Integer releaseYear) {
        this.releaseYear = releaseYear;
    }

    public void setEngineCapacity(Integer engineCapacity) {
        this.engineCapacity = engineCapacity;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("Автомобиль: ");
        if (!"Без названия".equals(title)) {
            sb.append(title);
        } else {
            sb.append("[Название не указано]");
        }

        sb.append("\nПроизводитель: ");
        if (!"Неизвестен".equals(producer)) {
            sb.append(producer);
        } else {
            sb.append("[Неизвестен]");
        }

        sb.append("\nГод выпуска: ");
        if (releaseYear != null && releaseYear > 0) {
            sb.append(releaseYear).append(" год");
        } else {
            sb.append("[Не указан]");
        }

        sb.append("\nОбъем двигателя: ");
        if (engineCapacity != null && engineCapacity > 0) {
            sb.append(engineCapacity).append(" см³");
        } else {
            sb.append("[Не указан]");
        }

        return sb.toString();
    }
}
