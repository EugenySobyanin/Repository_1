package org.example;

import java.util.ArrayList;
import java.util.List;

public class City {
    private String title;
    private int population;
    private List<String> attractions;

    // Конструктор по умолчанию
    public City(){
        title = null;
        population = 0;
        attractions = new ArrayList<>();
    }

    // Конструктор с 3 параметрами
    public City(String title, int population, List<String> attractions){
        this.title = title;
        this.population = population;
        this.attractions = attractions != null ? new ArrayList<>(attractions) : new ArrayList<>();
    }

    // Конструктор с 2 параметрами
    public City(String title, int population){
        this(title, population, new ArrayList<>());
    }

    // Конструктор с 1 параметром
    public City(String title){
        this(title, 0, new ArrayList<>());
    }

    // Геттеры
    public String getTitle() {
        return title;
    }

    public int getPopulation() {
        return population;
    }

    public List<String> getAttractions() {
        return attractions;
    }

    // Сеттеры
    public void setTitle(String title) {
        this.title = title;
    }

    public void setPopulation(int population) {
        this.population = population;
    }

    public void setAttractions(List<String> attractions) {
        this.attractions = attractions != null ? new ArrayList<>(attractions) : new ArrayList<>();
    }

    // Добавление достопримечательности
    public void addAttraction(String attraction) {
        if (attraction != null && !attraction.trim().isEmpty()) {
            attractions.add(attraction.trim());
            System.out.println("Достопримечательность '" + attraction + "' добавлена в город " + title);
        } else {
            System.out.println("Некорректное название достопримечательности");
        }
    }

    // Увеличение населения на заданное значение
    public void increasePopulation(int increment) {
        if (increment > 0) {
            population += increment;
            System.out.println("Население города " + title + " увеличено на " + increment +
                    ". Теперь: " + population + " человек.");
        } else {
            System.out.println("Прирост населения должен быть положительным числом");
        }
    }

    // Получение информации о городе
    public String getCityInfo() {
        StringBuilder info = new StringBuilder();
        info.append("Город: ").append(title != null ? title : "Неизвестно").append("\n");
        info.append("Население: ").append(population).append(" человек\n");

        if (attractions != null && !attractions.isEmpty()) {
            info.append("Достопримечательности (").append(attractions.size()).append("):\n");
            for (int i = 0; i < attractions.size(); i++) {
                info.append("  ").append(i + 1).append(". ").append(attractions.get(i)).append("\n");
            }
        } else {
            info.append("Достопримечательности: нет\n");
        }

        return info.toString();
    }

    // Проверка, является ли город крупным (население > 1 млн)
    public boolean isLargeCity() {
        return population > 1_000_000;
    }
}
