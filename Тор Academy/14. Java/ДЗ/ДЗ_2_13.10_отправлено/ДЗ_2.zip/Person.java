package org.example;

import java.io.PrintWriter;
import java.time.LocalDate;


public class Person {
    protected String fullName;
    protected int age;
    protected String profession;

    // Основной конструктор
    public Person(String fullName, int age, String profession){
      this.fullName = fullName != null ? fullName : "Unknown";
      this.age = age;
      this.profession = profession != null ? profession : "Unemployed";
    }

    // Конструктор с 2 параметрами
    public Person(String fullName, int age){
        this(fullName, age, null);
    }

    // Конструктор с 2 параметрами
    public Person(String fullName, String profession){
        this(fullName, 0, profession);
    }

    // Конструктор с 1 параметром
    public Person(String fullName){
        this(fullName, 0);
    }

    // Конструктор без параметров
    public Person(){
        this(null);
    }

    // Метод для проверки может ли человек работать
    public boolean canWork(){
        return age >= 18 && !"Unemployed".equals(profession);
    }

    public boolean canWork(String specificProfession){
        return age >= 18 && specificProfession.equals(profession);
    }

    public boolean canWork(int minAge){
        return age >= minAge && !"Unemployed".equals(profession);
    }

    public boolean canWork(String specificProfession, int minAge){
        return age >= minAge && specificProfession.equals(profession);
    }

    // Получение информации
    public String getInfo(){
        return fullName + " - (" + age + ")";
    }

    public String getInfo(boolean includeProfession){
        if (includeProfession){
            return fullName + " - (" + age + ") - " + profession;
        }
        return getInfo();
    }
}
