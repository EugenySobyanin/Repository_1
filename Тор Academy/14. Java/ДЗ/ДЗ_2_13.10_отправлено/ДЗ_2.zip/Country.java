package org.example;

import java.util.ArrayList;
import java.util.List;

public class Country {
    private String name;
    private long population;
    private String capital;
    private double area; // в квадратных километрах
    private String currency;
    private List<City> cities;

    // Конструктор по умолчанию
    public Country() {
        name = null;
        population = 0;
        capital = null;
        area = 0.0;
        currency = null;
        cities = new ArrayList<>();
    }

    // Конструктор со всеми параметрами
    public Country(String name, long population, String capital, double area,
                   String currency, List<City> cities) {
        this.name = name;
        this.population = population;
        this.capital = capital;
        this.area = area;
        this.currency = currency;
        this.cities = cities != null ? new ArrayList<>(cities) : new ArrayList<>();
    }

    // Конструктор с основными параметрами
    public Country(String name, long population, String capital, double area, String currency) {
        this(name, population, capital, area, currency, new ArrayList<>());
    }

    // Конструктор с минимальными параметрами
    public Country(String name, String capital) {
        this(name, 0, capital, 0.0, null, new ArrayList<>());
    }

    // Конструктор с 1 параметром
    public Country(String name) {
        this(name, 0, null, 0.0, null, new ArrayList<>());
    }

    // Сеттеры
    public void setName(String name) {
        this.name = name;
    }

    public void setPopulation(long population) {
        if (population >= 0) {
            this.population = population;
        }
    }

    public void setCapital(String capital) {
        this.capital = capital;
    }

    public void setArea(double area) {
        if (area >= 0) {
            this.area = area;
        }
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public void setCities(List<City> cities) {
        this.cities = cities != null ? new ArrayList<>(cities) : new ArrayList<>();
    }

    // Геттеры
    public String getName() {
        return name;
    }

    public long getPopulation() {
        return population;
    }

    public String getCapital() {
        return capital;
    }

    public double getArea() {
        return area;
    }

    public String getCurrency() {
        return currency;
    }

    public List<City> getCities() {
        return new ArrayList<>(cities); // Возвращаем копию для безопасности
    }

    // Методы

    // 1. Добавление города в страну
    public void addCity(City city) {
        if (city != null && city.getTitle() != null) {
            cities.add(city);
            System.out.println("Город '" + city.getTitle() + "' добавлен в страну " + name);
        } else {
            System.out.println("Некорректный город для добавления");
        }
    }

    // 2. Увеличение населения страны
    public void increasePopulation(long increment) {
        if (increment > 0) {
            population += increment;
            System.out.println("Население страны " + name + " увеличено на " + increment +
                    ". Теперь: " + population + " человек.");
        } else {
            System.out.println("Прирост населения должен быть положительным числом");
        }
    }

    // 3. Получение информации о стране
    public String getCountryInfo() {
        StringBuilder info = new StringBuilder();
        info.append("Страна: ").append(name != null ? name : "Неизвестно").append("\n");
        info.append("Столица: ").append(capital != null ? capital : "Не указана").append("\n");
        info.append("Население: ").append(String.format("%,d", population)).append(" человек\n");
        info.append("Площадь: ").append(String.format("%,.1f", area)).append(" км²\n");
        info.append("Валюта: ").append(currency != null ? currency : "Не указана").append("\n");
        info.append("Плотность населения: ").append(getPopulationDensity()).append(" чел/км²\n");

        if (cities != null && !cities.isEmpty()) {
            info.append("Крупные города (").append(cities.size()).append("):\n");
            for (int i = 0; i < cities.size(); i++) {
                City city = cities.get(i);
                info.append("  ").append(i + 1).append(". ").append(city.getTitle())
                        .append(" (").append(String.format("%,d", city.getPopulation())).append(" чел.)\n");
            }
        } else {
            info.append("Крупные города: не указаны\n");
        }

        return info.toString();
    }

    // 4. Расчет плотности населения
    public double getPopulationDensity() {
        if (area > 0) {
            return (double) population / area;
        }
        return 0.0;
    }

    // 5. Проверка, является ли страна крупной по населению
    public boolean isLargeCountry() {
        return population > 50_000_000;
    }

    // 6. Проверка, является ли страна большой по площади
    public boolean isBigCountry() {
        return area > 1_000_000;
    }

    // 7. Поиск города по названию
    public City findCityByName(String cityName) {
        if (cityName != null && cities != null) {
            for (City city : cities) {
                if (city.getTitle() != null && city.getTitle().equalsIgnoreCase(cityName.trim())) {
                    return city;
                }
            }
        }
        return null;
    }

    // 8. Расчет общего населения всех городов в списке
    public long getTotalCitiesPopulation() {
        long total = 0;
        if (cities != null) {
            for (City city : cities) {
                total += city.getPopulation();
            }
        }
        return total;
    }

    // 9. Добавление достопримечательности в столицу
    public void addAttractionToCapital(String attraction) {
        if (capital != null && attraction != null) {
            City capitalCity = findCityByName(capital);
            if (capitalCity != null) {
                capitalCity.addAttraction(attraction);
                System.out.println("Достопримечательность добавлена в столицу " + capital);
            } else {
                System.out.println("Столица '" + capital + "' не найдена в списке городов");
            }
        } else {
            System.out.println("Не указана столица или достопримечательность");
        }
    }

    // 10. Получение среднего населения городов
    public double getAverageCityPopulation() {
        if (cities != null && !cities.isEmpty()) {
            return (double) getTotalCitiesPopulation() / cities.size();
        }
        return 0.0;
    }
}
