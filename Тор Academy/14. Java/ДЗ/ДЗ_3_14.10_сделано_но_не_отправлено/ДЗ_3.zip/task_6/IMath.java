package org.example;

public interface IMath {
    int Max();
    int Min();
    float Avg();
}
