public interface ISort {
    void SortAsc();
    void SortDesc();
}
