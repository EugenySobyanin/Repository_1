import java.util.Arrays;
import java.util.Collections;

public class TestISort {
    private static final int[] ARRAY= {7, 3, 1, 2, 7, 5, 5, 4, 1, 2};

    // Констурктор
    public TestISort(){
        testSortAsc();
        testSortDesc();
    }

    // Проверка сортировки по возрастанию
    private Boolean testSortAsc() {
        int[] copy1 = Arrays.copyOf(ARRAY, ARRAY.length);
        int[] copy2 = Arrays.copyOf(ARRAY, ARRAY.length);

        Arrays.sort(copy1);
        Array arr = new Array(copy2);
        arr.SortAsc();
        if (Arrays.equals(copy2, arr.getNumbers())){
            System.out.println("Метод SortAsc работает правильно!");
            return true;
        }
        System.out.println("Метод SortAsc сломался!");
        return false;
    }

    // Проверка сортировки по убыванию
    private Boolean testSortDesc() {
        int[] copy1 = Arrays.copyOf(ARRAY, ARRAY.length);
        int[] copy2 = Arrays.copyOf(ARRAY, ARRAY.length);

        // Способ 1: Сортировка по убыванию для Integer[]
        Integer[] integerCopy = Arrays.stream(copy1)
                .boxed()
                .toArray(Integer[]::new);
        Arrays.sort(integerCopy, Collections.reverseOrder());

        // Конвертируем обратно в int[] для сравнения
        for (int i = 0; i < copy1.length; i++) {
            copy1[i] = integerCopy[i];
        }

        Array arr = new Array(copy2);
        arr.SortDesc();

        if (Arrays.equals(copy1, arr.getNumbers())) {
            System.out.println("Метод SortDesc работает правильно!");
            return true;
        }
        System.out.println("Метод SortDesc сломался!");
        return false;
    }
}
