import java.util.*;
import java.util.stream.Collectors;

public class HomeWork1 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        while (true){
            System.out.print("Введите номер задания: ");
            int taskNumber = scanner.nextInt();

            switch (taskNumber){
                case 1:
                    Tasks.task1();
                    break;
                case 2:
                    Tasks.task2(scanner);
                    break;
                case 3:
                    Tasks.task3(scanner);
                    break;
                case 4:
                    Tasks.task4(scanner);
                    break;
                case 5:
                    Tasks.task5(scanner);
                    break;
                case 6:
                    Tasks.task6(scanner);
                    break;
                case 7:
                    Tasks.task7(scanner);
                    break;
                case 8:
                    Tasks.task8(scanner);
                    break;
                case 9:
                    Tasks.task9();
                    break;
                case 10:
                    Tasks.task10();
                    break;
                case 11:
                    Tasks.task11(100, "vertical", '@');
                    break;
                case 12:
                    Tasks.task12(scanner);
                    break;
                default:
                    System.out.println("Задания под номером " +
                            taskNumber + " нет.");
            }
        }
    }
}
