import java.util.*;
import java.util.stream.Collectors;

public class Tasks {

    // Задание 1.
    protected static void task1(){
        System.out.println("\"Your time is limited,\n" +
                "\tso don't waste it\n" +
                "\t\tliving some one else's life\"\n" +
                "\t\t\tSteve Jobs");
    }

    // Заданиe 2.
    protected static void task2(Scanner scanner){
        try {
            System.out.print("Введите 2 числа через пробел: ");
            int num1 = scanner.nextInt();
            int num2 = scanner.nextInt();

            if (num1 == 0){
                System.out.println("Ошибка! Деление на 0");
                return;
            }

            System.out.println(num2 * 100 / num1 );
        }
        catch (InputMismatchException e){
            System.out.println("Ошибка: введите два целых числа!");
            scanner.nextLine();
        }

    }

    // Задание 3.
    protected static void task3(Scanner scanner){
        try {
            String concatenate = "";
            System.out.print("Введите 3 числа через пробел: ");
            for (int i = 0; i < 3; ++i){
                int num = scanner.nextInt();
                concatenate += String.valueOf(num);
            }
            int result = Integer.parseInt(concatenate);
            System.out.println("Число: " + result + "\n" +
                    "Тип: " + ((Object)result).getClass().getSimpleName());
        }
        catch (InputMismatchException e){
            System.out.println("Ошибка: введите три целых числа!");
            scanner.nextLine();
        }
    }

    // Задание 4.
    protected static void task4(Scanner scanner){
        try {
            System.out.print("Введите шестизначное число: ");
            int num = scanner.nextInt();
            String numToString = String.valueOf(num);

            if (numToString.length() != 6){
                System.out.println("Нужно ввести шестизначное число.");
                return;
            }
            List<String> numToLst = Arrays.asList(numToString.split(""));

            for (int i = 0; i < numToLst.size() / 2 - 1; ++i) {
                String first = numToLst.get(i);
                numToLst.set(i, numToLst.get(numToLst.size() - 1 - i));
                numToLst.set(numToLst.size() - 1 - i, first);
            }

            System.out.println("Результат: " + String.join("", numToLst));


        }
        catch (InputMismatchException e){
            System.out.println("Ошибка: введите шестизначное целое число!");
            scanner.nextLine();
        }
    }

    // Задание 5.
    protected static void task5(Scanner scanner){
        try {
            System.out.print("Введите номер месяца (от 1 до 12): ");
            int mounthNum = scanner.nextInt();

            if (mounthNum < 1 || mounthNum > 12){
                System.out.println("Введите число от 1 до 12");
                return;
            }

            if (Arrays.asList(1, 2, 3).contains(mounthNum)){
                System.out.println("Winter");
            }
            else if (Arrays.asList(3, 4, 5).contains(mounthNum)) {
                System.out.println("Spring");
            }
            else if (Arrays.asList(6, 7, 8).contains(mounthNum)) {
                System.out.println("Summer");
            }
            else {
                System.out.println("Autumn");
            }
        }
        catch (InputMismatchException e){
            System.out.println("Ошибка: введите число от 1 до 12!");
            scanner.nextLine();
        }
    }

    // Задание 6.
    protected static void task6(Scanner scanner){
        try {
            System.out.print("Введите количество метров: ");
            int meterCount = scanner.nextInt();

            System.out.println("Выберите один из вариантов:\n" +
                    "Мили - м\nДюймы - д\nЯрды - я");
            String userChoice = scanner.next();

            switch (userChoice){
                case("м"):
                    System.out.println(meterCount * 0.000621);
                    break;
                case("д"):
                    System.out.println(meterCount * 39.37);
                    break;
                case("я"):
                    System.out.println(meterCount * 1.09);
                    break;
                default:
                    System.out.println("Ваш выбор не соответствует ожиданиям.");
            }
        }
        catch (InputMismatchException e){
            System.out.println("Ошибка! Это должно быть целое число.");
            scanner.nextLine();
        }
    }

    // Задание 7
    protected static void task7(Scanner scanner){
        try {
            System.out.println("Введите 2 целых числа через пробел: ");
            int start = scanner.nextInt();
            int end = scanner.nextInt();

            if (end < start){
                int temp = start;
                start = end;
                end = temp;
            }

            List<Integer> result = new ArrayList<>();

            for (int i = start; i <= end; ++i){
                if (i % 2 != 0){
                    result.add(i);
                }
            }
            System.out.println("Результат: " + result.toString());

        }
        catch (InputMismatchException e){
            System.out.println("Ошибка! Нужно ввести 2 целых числа через пробел.");
            scanner.nextLine();
        }
    }

    // Задание 8
    protected static void task8(Scanner scanner){
        try {
            System.out.print("Укажите диапазон (2 целых числа от 2 до 9)");
            int start = scanner.nextInt();
            int end = scanner.nextInt();

            if (end < start) {
                int temp = start;
                start = end;
                end = temp;
            }

            start = start < 2 ? 2 : start;
            end = end > 9 ? 9 : end;

            for (int i = 2; i <= 10; ++i){
                for (int j = start; j <= end; ++j){
                    System.out.print(j + " * " + i + "= " + i * j + "\t");
                }
                System.out.print("\n");
            }

        }
        catch (InputMismatchException e){
            System.out.println("Ошибка! Нужно ввести 2 целых числа через пробел.");
            scanner.nextLine();
        }
    }

    // Задание 9
    protected static void task9() {
        int len = 1000;
        int nums[] = new int [len];

        for (int i = 0; i < nums.length; ++i){
            nums[i] = (int)(Math.random() * 200) - 100;
        }

        int max = Arrays.stream(nums).max().getAsInt();
        int min = Arrays.stream(nums).min().getAsInt();
        long positiveCount = Arrays.stream(nums).filter(n -> n > 0).count();
        long negativeCount = Arrays.stream(nums).filter(n -> n < 0).count();
        long zeroCount = Arrays.stream(nums).filter(n -> n == 0).count();

        String resultStr = "Количество элементов: " + len +
                "\nМаксимальное значение: " + max +
                "\nМинимальне значение: " + min +
                "\nКоличество положительных элементов: " + positiveCount +
                "\nКоличество отрицательных элементов: " + negativeCount +
                "\nКоличестов нулевых элементов: " + zeroCount;

        System.out.println(Arrays.toString(nums));
        System.out.print(resultStr);
    }

    // Задание 10
    protected static void task10(){
        int len = 100;
        int nums[] = new int[len];

        for (int i = 0; i < nums.length; ++i){
            nums[i] = (int)(Math.random() * 60) - 25;
        }

        List<Integer> numsEven = Arrays.stream(nums)
                .filter(n -> n % 2 == 0)
                .boxed()
                .collect(Collectors.toList());
        List<Integer> numsOdd = Arrays.stream(nums)
                .filter(n -> n % 2 != 0)
                .boxed()
                .collect(Collectors.toList());
        List<Integer> numsPositive = Arrays.stream(nums)
                .filter(n -> n > 0)
                .boxed()
                .collect(Collectors.toList());
        List<Integer> numsNegative = Arrays.stream(nums)
                .filter(n -> n < 0)
                .boxed()
                .collect(Collectors.toList());

        System.out.println("Исходный массив: " + Arrays.toString(nums));
        System.out.println("Только четные: " + numsEven);
        System.out.println("Только нечетные: " + numsOdd);
        System.out.println("Только положительные: " + numsPositive);
        System.out.println("Только отрицательные: " + numsNegative);
    }

    // Задание 11
    protected static void task11(int len, String direction, char symbol){
        for (int i = 0; i <= len; ++i){
            if (direction.matches("(?i)h*o*r*i*z*o*n*t*a*l*")){
                System.out.print(symbol);
            }
            else if (direction.matches("(?i)v*e*r*t*i*c*a*l")) {
                System.out.println(symbol);
            }
        }
    }

    // Задание 12
    protected static void task12(Scanner scanner){
        int len = 20;
        Integer nums[] = new Integer[len];

        for (int i = 0; i < nums.length; ++i){
            nums[i] = (int)(Math.random() * 20) - 10;
        }

        System.out.println("Выберите направление сортировки\n" +
                "По возростанию - 0\nПо убыванию - 1");
        int userChoice = 0;
        try {
            userChoice = scanner.nextInt();
            if (userChoice != 0 && userChoice != 1){
                System.out.println("Ошибка! Нужно ввести 0 или 1.");
                return;
            }
        }
        catch (InputMismatchException e){
            System.out.println("Ошибка! Нужно ввести 0 или 1.");
            scanner.nextLine();
        }

        System.out.println("Исходный массив: " + Arrays.toString(nums));

        if (userChoice == 0){
            Arrays.sort(nums);
        }
        else {
            Arrays.sort(nums, Collections.reverseOrder());
        }

        System.out.println("Отсортированный массив: " + Arrays.toString(nums));
    }
}
